/*
 * Copyright 1999 Sun Microsystems, Inc.  All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */

package com.sun.tools.example.debug.event;

import com.sun.jdi.*;
import com.sun.jdi.event.*;

public class ClassUnloadEventSet extends AbstractEventSet {

    ClassUnloadEventSet(EventSet jdiEventSet) {
        super(jdiEventSet);
    }

    /**
     * Returns the name of the class that has been unloaded.
     */
    public String getClassName() {
        return ((ClassUnloadEvent)oneEvent).className();
    }

    /**
     * Returns the JNI-style signature of the class that has been unloaded.
     */
    public String getClassSignature() {
        return ((ClassUnloadEvent)oneEvent).classSignature();
    }

    public void notify(JDIListener listener) {
        listener.classUnload(this);
    }
}
