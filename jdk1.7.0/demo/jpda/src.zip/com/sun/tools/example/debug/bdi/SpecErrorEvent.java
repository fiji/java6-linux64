/*
 * Copyright 1999 Sun Microsystems, Inc.  All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */

package com.sun.tools.example.debug.bdi;

import java.util.EventObject;

public class SpecErrorEvent extends SpecEvent {

    private Exception reason;

    public SpecErrorEvent(EventRequestSpec eventRequestSpec,
                                 Exception reason) {
        super(eventRequestSpec);
        this.reason = reason;
    }

    public Exception getReason() {
        return reason;
    }
}
