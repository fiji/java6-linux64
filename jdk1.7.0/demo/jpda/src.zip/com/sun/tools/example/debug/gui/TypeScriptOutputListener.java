/*
 * Copyright 1998-1999 Sun Microsystems, Inc.  All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */

package com.sun.tools.example.debug.gui;

import javax.swing.*;
import com.sun.tools.example.debug.bdi.OutputListener;

public class TypeScriptOutputListener implements OutputListener {

    private TypeScript script;
    private boolean appendNewline;

    public TypeScriptOutputListener(TypeScript script) {
        this(script, false);
    }

    public TypeScriptOutputListener(TypeScript script, boolean appendNewline) {
        this.script = script;
        this.appendNewline = appendNewline;
    }

    public void putString(String s) {
        script.append(s);
        if (appendNewline)
            script.newline();
    }

}
