/*
 * Copyright 1999 Sun Microsystems, Inc.  All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */

package com.sun.tools.example.debug.event;

import com.sun.jdi.event.*;

public class VMDeathEventSet extends AbstractEventSet {

    VMDeathEventSet(EventSet jdiEventSet) {
        super(jdiEventSet);
    }

    public void notify(JDIListener listener) {
        listener.vmDeath(this);
    }
}
