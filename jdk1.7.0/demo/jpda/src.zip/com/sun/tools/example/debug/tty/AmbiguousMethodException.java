/*
 * Copyright 1998-2001 Sun Microsystems, Inc.  All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */

package com.sun.tools.example.debug.tty;

public class AmbiguousMethodException extends Exception
{
    public AmbiguousMethodException()
    {
        super();
    }

    public AmbiguousMethodException(String s)
    {
        super(s);
    }
}
