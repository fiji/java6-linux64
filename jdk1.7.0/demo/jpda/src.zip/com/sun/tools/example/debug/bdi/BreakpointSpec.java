/*
 * Copyright 1999 Sun Microsystems, Inc.  All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */

package com.sun.tools.example.debug.bdi;

import com.sun.jdi.request.*;

public abstract class BreakpointSpec extends EventRequestSpec {

    BreakpointSpec(EventRequestSpecList specs, ReferenceTypeSpec refSpec) {
        super(specs, refSpec);
    }

    void notifySet(SpecListener listener, SpecEvent evt) {
        listener.breakpointSet(evt);
    }

    void notifyDeferred(SpecListener listener, SpecEvent evt) {
        listener.breakpointDeferred(evt);
    }

    void notifyResolved(SpecListener listener, SpecEvent evt) {
        listener.breakpointResolved(evt);
    }

    void notifyDeleted(SpecListener listener, SpecEvent evt) {
        listener.breakpointDeleted(evt);
    }

    void notifyError(SpecListener listener, SpecErrorEvent evt) {
        listener.breakpointError(evt);
    }
}
