/*
 * Copyright 1998-1999 Sun Microsystems, Inc.  All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */

package com.sun.tools.example.debug.gui;

import java.io.*;

public class TypeScriptWriter extends Writer {

    TypeScript script;

    public TypeScriptWriter(TypeScript script) {
        this.script = script;
    }

    public void write(char[] cbuf, int off, int len) throws IOException {
        script.append(String.valueOf(cbuf, off, len));
    }

    public void flush() {
        script.flush();
    }

    public void close() {
        script.flush();
    }
}
