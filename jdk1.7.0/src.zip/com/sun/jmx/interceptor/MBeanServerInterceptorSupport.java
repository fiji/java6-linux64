/*
 * Copyright 2008 Sun Microsystems, Inc.  All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */

package com.sun.jmx.interceptor;

import java.io.ObjectInputStream;
import javax.management.InstanceNotFoundException;
import javax.management.MBeanException;
import javax.management.ObjectName;
import javax.management.OperationsException;
import javax.management.ReflectionException;
import javax.management.loading.ClassLoaderRepository;

/**
 * An abstract class for MBeanServerInterceptorSupport.
 * Some methods in MBeanServerInterceptor should never be called.
 * This base class provides an implementation of these methods that simply
 * throw an {@link UnsupportedOperationException}.
 * <p><b>
 * This API is a Sun internal API and is subject to changes without notice.
 * </b></p>
 * @since 1.7
 */
public abstract class MBeanServerInterceptorSupport
        implements MBeanServerInterceptor {
    /**
     * This method should never be called.
     * Throws UnsupportedOperationException.
     */
    public Object instantiate(String className)
            throws ReflectionException, MBeanException {
        throw new UnsupportedOperationException("Not applicable.");
    }

    /**
     * This method should never be called.
     * Throws UnsupportedOperationException.
     */
    public Object instantiate(String className, ObjectName loaderName)
            throws ReflectionException, MBeanException,
            InstanceNotFoundException {
        throw new UnsupportedOperationException("Not applicable.");
    }

    /**
     * This method should never be called.
     * Throws UnsupportedOperationException.
     */
    public Object instantiate(String className, Object[] params,
            String[] signature) throws ReflectionException, MBeanException {
        throw new UnsupportedOperationException("Not applicable.");
    }

    /**
     * This method should never be called.
     * Throws UnsupportedOperationException.
     */
    public Object instantiate(String className, ObjectName loaderName,
            Object[] params, String[] signature)
            throws ReflectionException, MBeanException,
            InstanceNotFoundException {
        throw new UnsupportedOperationException("Not applicable.");
    }

    /**
     * This method should never be called.
     * Throws UnsupportedOperationException.
     */
    @Deprecated
    public ObjectInputStream deserialize(ObjectName name, byte[] data)
            throws InstanceNotFoundException, OperationsException {
        throw new UnsupportedOperationException("Not applicable.");
    }

    /**
     * This method should never be called.
     * Throws UnsupportedOperationException.
     */
    @Deprecated
    public ObjectInputStream deserialize(String className, byte[] data)
            throws OperationsException, ReflectionException {
        throw new UnsupportedOperationException("Not applicable.");
    }

    /**
     * This method should never be called.
     * Throws UnsupportedOperationException.
     */
    @Deprecated
    public ObjectInputStream deserialize(String className,
            ObjectName loaderName, byte[] data)
            throws InstanceNotFoundException, OperationsException,
            ReflectionException {
        throw new UnsupportedOperationException("Not applicable.");
    }

    /**
     * This method should never be called.
     * Throws UnsupportedOperationException.
     */
    public ClassLoaderRepository getClassLoaderRepository() {
        throw new UnsupportedOperationException("Not applicable.");
    }

}
