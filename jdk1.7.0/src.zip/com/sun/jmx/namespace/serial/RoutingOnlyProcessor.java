/*
 * Copyright 2008 Sun Microsystems, Inc.  All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */

package com.sun.jmx.namespace.serial;

import com.sun.jmx.namespace.ObjectNameRouter;


import javax.management.ObjectInstance;
import javax.management.ObjectName;

/**
 * Class RoutingOnlyProcessor. A RewritingProcessor that uses
 * Java Serialization to rewrite ObjectNames contained in
 * input and results...
 *
 * <p><b>
 * This API is a Sun internal API and is subject to changes without notice.
 * </b></p>
 * @since 1.7
 */
class RoutingOnlyProcessor extends RewritingProcessor {

    final ObjectNameRouter router;

    public RoutingOnlyProcessor(String targetDirName) {
        this(targetDirName,null);
    }

    /** Creates a new instance of RoutingOnlyProcessor */
    public RoutingOnlyProcessor(final String remove, final String add) {
        super(new IdentityProcessor());
        if (remove == null || add == null)
            throw new IllegalArgumentException("Null argument");
        router = new ObjectNameRouter(remove,add);
    }

    @Override
    public final ObjectName toTargetContext(ObjectName sourceName) {
        return router.toTargetContext(sourceName,false);
    }

    @Override
    public final ObjectName toSourceContext(ObjectName targetName) {
        return router.toSourceContext(targetName,false);
    }

    @Override
    public final ObjectInstance toTargetContext(ObjectInstance sourceMoi) {
        return router.toTargetContext(sourceMoi,false);
    }
}
