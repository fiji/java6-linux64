/*
 * Copyright 2008 Sun Microsystems, Inc.  All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */

package com.sun.jmx.namespace.serial;


import javax.management.ObjectInstance;
import javax.management.ObjectName;

/**
 * Class RoutingOnlyProcessor. A RewritingProcessor that uses
 * Java Serialization to rewrite ObjectNames contained in
 * input & results...
 * <p><b>
 * This API is a Sun internal API and is subject to changes without notice.
 * </b></p>
 *
 * @since 1.7
 */
class IdentityProcessor extends RewritingProcessor {


    /** Creates a new instance of SerialRewritingProcessor */
    public IdentityProcessor() {
    }

    @Override
    public <T> T rewriteOutput(T result) {
        return result;
    }

    @Override
    public <T> T rewriteInput(T input) {
        return input;
    }

    @Override
    public final ObjectName toTargetContext(ObjectName sourceName) {
        return sourceName;
    }

    @Override
    public final ObjectInstance toTargetContext(ObjectInstance sourceMoi) {
        return sourceMoi;
    }

    @Override
    public final ObjectName toSourceContext(ObjectName targetName) {
        return targetName;
    }

}
