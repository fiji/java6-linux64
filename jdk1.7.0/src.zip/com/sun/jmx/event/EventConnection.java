/*
 * Copyright 2002-2008 Sun Microsystems, Inc.  All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */

package com.sun.jmx.event;

import java.io.IOException;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import javax.management.MBeanServerConnection;
import javax.management.event.EventClient;
import javax.management.event.EventClientDelegate;
import javax.management.event.EventConsumer;
import javax.management.event.NotificationManager;

/**
 * Override the methods related to the notification to use the
 * Event service.
 */
public interface EventConnection extends MBeanServerConnection, EventConsumer {
    public EventClient getEventClient();

    public static class Factory {
        public static EventConnection make(
                final MBeanServerConnection mbsc,
                final EventClient eventClient)
                throws IOException {
            if (!mbsc.isRegistered(EventClientDelegate.OBJECT_NAME)) {
                throw new IOException(
                        "The server does not support the event service.");
            }
            InvocationHandler ih = new InvocationHandler() {
                public Object invoke(Object proxy, Method method, Object[] args)
                        throws Throwable {
                    Class<?> intf = method.getDeclaringClass();
                    try {
                        if (intf.isInstance(eventClient))
                            return method.invoke(eventClient, args);
                        else
                            return method.invoke(mbsc, args);
                    } catch (InvocationTargetException e) {
                        throw e.getCause();
                    }
                }
            };
            // It is important to declare NotificationManager.class first
            // in the array below, so that the relevant addNL and removeNL
            // methods will show up with method.getDeclaringClass() as
            // being from that interface and not MBeanServerConnection.
            return (EventConnection) Proxy.newProxyInstance(
                    NotificationManager.class.getClassLoader(),
                    new Class<?>[] {
                        NotificationManager.class, EventConnection.class,
                    },
                    ih);
        }
    }
}
