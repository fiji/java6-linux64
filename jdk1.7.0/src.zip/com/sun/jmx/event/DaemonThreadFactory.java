/*
 * Copyright 2007-2008 Sun Microsystems, Inc.  All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */

package com.sun.jmx.event;

import com.sun.jmx.remote.util.ClassLogger;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

public class DaemonThreadFactory implements ThreadFactory {
    public DaemonThreadFactory(String nameTemplate) {
        this(nameTemplate, null);
    }

    // nameTemplate should be a format with %d in it, which will be replaced
    // by a sequence number of threads created by this factory.
    public DaemonThreadFactory(String nameTemplate, ThreadGroup threadGroup) {
        if (logger.debugOn()) {
            logger.debug("DaemonThreadFactory",
                    "Construct a new daemon factory: "+nameTemplate);
        }

        if (threadGroup == null) {
            SecurityManager s = System.getSecurityManager();
            threadGroup = (s != null) ? s.getThreadGroup() :
                                  Thread.currentThread().getThreadGroup();
        }

        this.nameTemplate = nameTemplate;
        this.threadGroup = threadGroup;
    }

    public Thread newThread(Runnable r) {
        final String name =
                String.format(nameTemplate, threadNumber.getAndIncrement());
        Thread t = new Thread(threadGroup, r, name, 0);
        t.setDaemon(true);
        if (t.getPriority() != Thread.NORM_PRIORITY)
            t.setPriority(Thread.NORM_PRIORITY);

        if (logger.debugOn()) {
            logger.debug("newThread",
                    "Create a new daemon thread with the name "+t.getName());
        }

        return t;
    }

    private final String nameTemplate;
    private final ThreadGroup threadGroup;
    private final AtomicInteger threadNumber = new AtomicInteger(1);

    private static final ClassLogger logger =
        new ClassLogger("com.sun.jmx.event", "DaemonThreadFactory");
}
