/*
 * Copyright 1999-2008 Sun Microsystems, Inc.  All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */

package com.sun.jmx.mbeanserver;

import java.lang.ref.WeakReference;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * <p>A factory for ThreadPoolExecutor objects that allows the same object to
 * be shared by all users of the factory that are in the same ThreadGroup.</p>
 */
// We return a ThreadPoolExecutor rather than the more general ExecutorService
// because we need to be able to call allowCoreThreadTimeout so that threads in
// the pool will eventually be destroyed when the pool is no longer in use.
// Otherwise these threads would keep the ThreadGroup alive forever.
public class PerThreadGroupPool<T extends ThreadPoolExecutor> {
    private final WeakIdentityHashMap<ThreadGroup, WeakReference<T>> map =
            WeakIdentityHashMap.make();

    public static interface Create<T extends ThreadPoolExecutor> {
        public T createThreadPool(ThreadGroup group);
    }

    private PerThreadGroupPool() {}

    public static <T extends ThreadPoolExecutor> PerThreadGroupPool<T> make() {
        return new PerThreadGroupPool<T>();
    }

    public synchronized T getThreadPoolExecutor(Create<T> create) {
        // Find out if there's already an existing executor for the calling
        // thread and reuse it. Otherwise, create a new one and store it in
        // the executors map. If there is a SecurityManager, the group of
        // System.getSecurityManager() is used, else the group of the calling
        // thread.
        SecurityManager s = System.getSecurityManager();
        ThreadGroup group = (s != null) ? s.getThreadGroup() :
            Thread.currentThread().getThreadGroup();
        WeakReference<T> wr = map.get(group);
        T executor = (wr == null) ? null : wr.get();
        if (executor == null) {
            executor = create.createThreadPool(group);
            executor.allowCoreThreadTimeOut(true);
            map.put(group, new WeakReference<T>(executor));
        }
        return executor;
    }
}
