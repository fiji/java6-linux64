/*
 * Copyright 2007-2008 Sun Microsystems, Inc.  All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */

package com.sun.jmx.mbeanserver;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import javax.management.NotCompliantMBeanException;
import javax.management.Notification;
import javax.management.openmbean.MXBeanMappingFactory;

/**
 * <p>A variant of {@code StandardMBeanSupport} where the only
 * methods included are public getters.  This is used by
 * {@code QueryNotificationFilter} to pretend that a Notification is
 * an MBean so it can have a query evaluated on it.  Standard queries
 * never set attributes or invoke methods but custom queries could and
 * we don't want to allow that.  Also we don't want to fail if a
 * Notification happens to have inconsistent types in a pair of getX and
 * setX methods, and we want to include the Object.getClass() method.
 */
public class NotificationMBeanSupport extends StandardMBeanSupport {
    public <T extends Notification> NotificationMBeanSupport(T n)
            throws NotCompliantMBeanException {
        super(n, Util.<Class<T>>cast(n.getClass()));
    }

    @Override
    MBeanIntrospector<Method> getMBeanIntrospector(MXBeanMappingFactory ignored) {
        return introspector;
    }

    private static class Introspector extends StandardMBeanIntrospector {
        @Override
        void checkCompliance(Class<?> mbeanType) {}

        @Override
        List<Method> getMethods(final Class<?> mbeanType)
                throws Exception {
            List<Method> methods = new ArrayList<Method>();
            for (Method m : mbeanType.getMethods()) {
                String name = m.getName();
                Class<?> ret = m.getReturnType();
                if (m.getParameterTypes().length == 0) {
                    if ((name.startsWith("is") && name.length() > 2 &&
                            ret == boolean.class) ||
                        (name.startsWith("get") && name.length() > 3 &&
                            ret != void.class)) {
                        methods.add(m);
                    }
                }
            }
            return methods;
        }

    }
    private static final MBeanIntrospector<Method> introspector =
            new Introspector();
}
